import React from 'react';

function Messages() {
  return (
    <div className='messages'>
      <h1>This is the Messages Page</h1>
      <br />
      <p>order #: ############# (multiple pictures)</p>

      
    </div>
  );
}

export default Messages;
