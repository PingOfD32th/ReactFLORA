import React from 'react';

function addItem() {
  return (
    <div className='addItem'>
      <h1>Form To add Item to Database</h1>
      <h3>Item Name:</h3>
      <h3>Item Link:</h3>
      <h3>Item Picture:</h3>
      <h3>Item Description:</h3>
      <h3>Item Price:</h3>
      <h3>Add Item:</h3>

      <h3>Edit Item:</h3>
      <h3>Delete Item:</h3>
    </div>
  );
}

export default addItem;
